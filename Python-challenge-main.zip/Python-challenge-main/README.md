# Python-challenge
Module 3 SMU homework with PyBank and Pypoll
This repo will display my knowledge of import os and csv and extracting the information and outputting it into a text file.
In PyBank I was able to break down the profit and loss over a period of time. 
With PyPoll I separated each candidates election information and displayed the winner
